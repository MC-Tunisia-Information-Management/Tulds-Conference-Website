<article class="mkdf-dl-item mkdf-item-space">
	<div class="mkdf-dl-item-inner">
		<?php echo wanderland_core_get_cpt_shortcode_module_template_part( 'destination', 'destination-list', 'layout-collections/gallery-overlay', '', $params ); ?>

		<a itemprop="url" class="mkdf-dli-link mkdf-block-drag-link" href="<?php echo get_permalink( get_the_ID() ); ?>"></a>
	</div>
</article>