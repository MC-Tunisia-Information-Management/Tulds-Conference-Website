<?php

require_once 'destination-slider.php';
require_once 'helper-functions.php';