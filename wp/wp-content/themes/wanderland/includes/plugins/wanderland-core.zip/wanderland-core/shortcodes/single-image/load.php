<?php

include_once WANDERLAND_CORE_SHORTCODES_PATH.'/single-image/functions.php';
include_once WANDERLAND_CORE_SHORTCODES_PATH.'/single-image/single-image.php';