<?php

include_once WANDERLAND_CORE_CPT_PATH . '/destination/destination-register.php';
include_once WANDERLAND_CORE_CPT_PATH . '/destination/helper-functions.php';