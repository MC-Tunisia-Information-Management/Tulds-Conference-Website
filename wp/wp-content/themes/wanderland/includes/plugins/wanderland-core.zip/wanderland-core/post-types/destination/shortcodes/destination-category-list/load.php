<?php

require_once 'destination-category-list.php';
require_once 'helper-functions.php';