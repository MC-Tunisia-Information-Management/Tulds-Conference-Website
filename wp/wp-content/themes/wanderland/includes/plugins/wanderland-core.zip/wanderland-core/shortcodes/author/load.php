<?php

include_once WANDERLAND_CORE_SHORTCODES_PATH . '/author/functions.php';
include_once WANDERLAND_CORE_SHORTCODES_PATH . '/author/author.php';