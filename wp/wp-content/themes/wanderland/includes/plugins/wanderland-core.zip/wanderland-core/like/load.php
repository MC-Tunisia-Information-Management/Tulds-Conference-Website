<?php

include_once WANDERLAND_CORE_ABS_PATH . '/like/like.php';
include_once WANDERLAND_CORE_ABS_PATH . '/like/like-functions.php';