<?php

include_once WANDERLAND_CORE_SHORTCODES_PATH . '/uncovering-sections/functions.php';
include_once WANDERLAND_CORE_SHORTCODES_PATH . '/uncovering-sections/uncovering-sections.php';
include_once WANDERLAND_CORE_SHORTCODES_PATH . '/uncovering-sections/uncovering-sections-item.php';